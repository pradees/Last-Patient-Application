package com.cg.bean;

import java.sql.Date;

public class PatientBean 
{
	
	private String patient_id;
	private String patient_name;
	private String phone;
	private int age;
    private String description;
    private Date date1;
    public Date getDate() {
		return date1;
	}
	public void setDate(Date date) {
		this.date1 = date;
	}
	
    
	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}
	public String getPatient_id() {
		return patient_id;
	}
	
    
    public String getPatient_name() {
		return patient_name;
	}
	public int getAge() {
		return age;
	}
	public String getPhone() {
		return phone;
	}
	public String getDescription() {
		return description;
	}
	
	
    public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Patient Details \n");
		sb.append("Patient Name: " +patient_name +"\n");
		sb.append("Phone Number: "+ phone +"\n");
		sb.append("Patient Age: "+ age +"\n");
		sb.append("Patient Description: "+ description +"\n");
		sb.append("Date: "+ date1);
		return sb.toString();
	}
    
    
}
