package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.PatientException.PatientException;
import com.cg.bean.PatientBean;
import com.cg.dao.PatientDAO;

public class PatientService implements IPatientservice

{
    PatientDAO  patientdao;
    
  //------------------------ 1. Patient Application --------------------------
  	/*******************************************************************************************************
  	 - Function Name	:	addDonorDetails
  	 - Input Parameters	:	patient object
  	 - Return Type		:	String id
  	 - Throws			:  	DonorException
  	 - Author			:	CAPGEMINI
  	 - Creation Date	:	14/02/2018
  	 - Description		:	adding patient to database calls dao method addDonorDetails(donor)
  	 * @throws PatientException 
  	 ********************************************************************************************************/
    
    
    
	@Override
	public String addPatientDetails(PatientBean patientbean) throws PatientException 
	{
		 patientdao = new PatientDAO();
		 String patientSeq;
		 patientSeq= patientdao.addPatientDetails(patientbean);
		return patientSeq;
	}
	
	//------------------------ 1. Patient Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	viewDonorDetails
		 - Input Parameters	:	String donorId
		 - Return Type		:	patient object
		 - Throws		    :  	DonorException
		 - Author		    :	CAPGEMINI
		 - Creation Date	:	18/11/2016
		 - Description		:	calls dao method viewDonorDetails(donorId)
		 ********************************************************************************************************/
	
	@Override
	public PatientBean viewPatientDetails(String Patient_id) throws PatientException
	{
		patientdao = new PatientDAO();
		PatientBean bean=null;
		bean= patientdao.viewPatientDetails(Patient_id);
		return bean;
	}
	
	//------------------------ 1. Patient Application --------------------------
		/*******************************************************************************************************
		 - Function Name	: retriveAll()
		 - Input Parameters	:	
		 - Return Type		: list
		 - Throws		    : PatientException
		 - Author	      	: CAPGEMINI 
		 - Creation Date	: 18/11/2016
		 - Description		: calls dao method retriveAllDetails()
		 ********************************************************************************************************/
	

	@Override
	public List<PatientBean> retriveAllDetails() throws PatientException
	{
		patientdao = new PatientDAO();
		List<PatientBean> patientList=null;
		patientList=patientdao.retriveAllDetails();
		// TODO Auto-generated method stub
		return patientList;
	}

	
	/*******************************************************************************************************
	 - Function Name	: validatePatient(DonorBean bean)
	 - Input Parameters	: PatientBean bean
	 - Return Type		: void
	 - Throws		    : PatienException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the PatientBean object
	 * @throws PatientException 
	 ********************************************************************************************************/
	
	
	public void validatePatient(PatientBean patientbean) throws PatientException 
	{
		List<String> validationErrors = new ArrayList<String>();
		
		if(!(isValidName(patientbean.getPatient_name()))) {
			validationErrors.add("\n Patient Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Phone Number
		if(!(isValidPhoneNumber1(patientbean.getPhone()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new PatientException(validationErrors +"");
	}

	public boolean isValidName(String Patient_name){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(Patient_name);
		return nameMatcher.matches();
	}
	public boolean isValidPhoneNumber1(String Phone){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(Phone);
		return phoneMatcher.matches();
	}
	
public boolean validatePatientId(String patient_id) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(patient_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
		
	
		// TODO Auto-generated method stub
		
	

	

}
