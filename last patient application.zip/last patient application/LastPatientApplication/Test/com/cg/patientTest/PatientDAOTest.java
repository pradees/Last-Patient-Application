package com.cg.patientTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.PatientException.PatientException;
import com.cg.bean.PatientBean;
import com.cg.dao.PatientDAO;



public class PatientDAOTest 
{
	static PatientDAO dao;
	static PatientBean patient;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new PatientDAO();
		patient = new PatientBean();
	}

	@Test
	public void testAddDonarDetails() throws PatientException {

		assertNotNull(dao.addPatientDetails(patient));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws PatientException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addPatientDetails(patient));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws PatientException {

		patient.setPatient_name("ShashwathiNew");
		patient.setPhone("9876543212");
		patient.setDescription("fever");
		patient.setAge(12);
		//assertEquals(1019, dao.addPatientDetails(patient));
		/*assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);*/

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws PatientException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws PatientException {
		assertNotNull(dao.viewPatientDetails("1020"));
	}

	@Ignore
	@Test
	public void testById1() throws PatientException {
		assertEquals("TestName", dao.viewPatientDetails("1020").getPatient_name());
	}

}
